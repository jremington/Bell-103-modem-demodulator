# Arabell300
Old school Arduino modem, Bell 103 and ITU V.21 compatible, at 300 baud.
